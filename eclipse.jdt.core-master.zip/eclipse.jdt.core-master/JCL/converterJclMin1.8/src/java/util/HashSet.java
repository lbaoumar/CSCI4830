package java.util;

import java.io.Serializable;

public class HashSet<E> extends AbstractSet<E> implements Set<E>, Cloneable, Serializable {
	private static final long serialVersionUID = 4886489800857586866L;
	public Iterator<E> iterator() {
		return null;
	}
	public boolean addAll(Collection<E> c) {
		return false;
	}
	public E get(int index) {
		return null;
	}
	public int size() {
		return 0;
	}
	public <T> T[] toArray(T[] o) {
		return null;
	}
}
