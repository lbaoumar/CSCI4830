/*******************************************************************************
 * Copyright (c) 2000, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package java.util;

public class Hashtable<U, V> implements Map<U, V> {
	public Hashtable(int i) {
	}
	public V get(U u) {
		return null;
	}
	public boolean containsKey(U u) {
		return false;
	}
	public void put(U u, V v) {
	}
    public synchronized Enumeration elements() {
    	return null;
    }
    public int size() {
    	return 0;
    }
    public synchronized Enumeration keys() {
    	return null;
    }
}
