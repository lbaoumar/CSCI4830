package java.util;

public abstract class AbstractCollection<E> implements Collection<E> {
}
