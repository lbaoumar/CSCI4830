package p1.p2;

public enum MyEnum2 {

	A, B, C, D;
	
}
