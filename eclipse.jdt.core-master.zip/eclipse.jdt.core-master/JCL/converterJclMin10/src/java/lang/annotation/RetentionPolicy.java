package java.lang.annotation;
public enum RetentionPolicy {
    CLASS,
    SOURCE,
    RUNTIME
}